package ch14.kt.q4;


public class StudentBiz {
    Student[] students = new Student[30];

    StudentBiz() {
        for (int i = 0; i < students.length; i++) {
            students[i] = new Student();

        }
    }


    public void addStudent(Student stu) {
        System.out.println("本班学生信息");
        for (int i = 0; i < students.length; i++) {
            if (students[i].id == 0) {
                students[i] = stu;
                break;

            }
        }

    }

    public void showStudents() {
        for (int i = 0; i < students.length; i++) {
            if (students[i].id != 0) {
                System.out.print(students[i].id + "   ");
                System.out.print(students[i].name + "   ");
                System.out.print(students[i].age + "   ");
                System.out.print(students[i].score + "   ");
                System.out.println();

            }

        }

    }


}
