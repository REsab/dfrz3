package ch14.lx.q4;

public class Customer {
     public String name;
     public  int age;
     public boolean isMember;

     public   void  showInfo(){


     }

}
