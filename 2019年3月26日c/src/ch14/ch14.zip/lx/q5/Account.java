package ch14.lx.q5;

public class Account {

     double money =0;

    public double getMoney() {
        return money;
    }
     public void save(double s){
         System.out.println(s);

     }
    public void depoit(double a){

    }

}
