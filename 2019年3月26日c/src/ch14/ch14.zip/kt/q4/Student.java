package ch14.kt.q4;

public class Student {
    public int id;
    public String name;
    public int age;
    public int score;


}
