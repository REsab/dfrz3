package ch15.kzc.q0;



public class ArrayFun {


    public static void print(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);

        }
    }
public static void revert(int [] arr){
        //折半
    for (int i = 0; i < arr.length/2; i++) {
         int temp=0;
         temp=arr[i];
         arr[i]=arr[arr.length-1-i];
         arr[arr.length-1-i]= temp;

    }



}

}
