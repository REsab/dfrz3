package ch15.kzc.q1;

import ch15.kzc.q0.ArrayFun;

import java.util.Arrays;
import java.util.Scanner;

public class Start {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] array = new int[5];
        System.out.println("请输入5个整数");
        for (int i = 0; i < array.length; i++) {
             array[i]=scanner.nextInt();
        }
        System.out.println("您小子这串数字牛逼啊");
        ArrayFun arrayFun=new ArrayFun();
        arrayFun.print(array);

    }

}
