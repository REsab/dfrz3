package ch15.kzc.q2;

import ch15.kzc.q0.ArrayFun;

import java.util.Scanner;

public class Start {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] array = new int[5];
        System.out.println("请输入5个整数");
        for (int i = 0; i < array.length; i++) {
            array[i]=scanner.nextInt();
        }

        ArrayFun arrayFun=new ArrayFun();
        System.out.println("反转前:");
        arrayFun.print(array);
         arrayFun.revert(array);
        System.out.println("反转后:");
        arrayFun.print(array);



    }

}
