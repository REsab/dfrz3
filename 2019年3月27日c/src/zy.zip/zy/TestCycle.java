package zy;


import java.util.zip.DeflaterOutputStream;

/**
 * test TestCycle
 */
public class TestCycle {

    public static void main(String[] args) {

        double radius =33;
        System.out.println("周长"+(Math.PI*radius*2));
        System.out.println("面积"+(Math.PI*radius*radius));

    }
}
