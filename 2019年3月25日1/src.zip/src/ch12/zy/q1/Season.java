package ch12.zy.q1;

public class Season {
    public  String spring(){
        return "春季";
    }    public  String spring(int x){
        return "春季";
    }
    public  String spring(int x,int y){
        return "春季";
    }
    public  String summer(){
        return "夏季";
    }
    public  String autumn(){
        return "秋季";
    }
    public  String winter(){
        return "冬季";
    }
}
