package ch12.zy.q4;

public class TestAccount {
    public static void main(String[] args) {
        Account user1=new Account();
        System.out.println("当前存款"+user1.getMoney()+"元");

    }

}
