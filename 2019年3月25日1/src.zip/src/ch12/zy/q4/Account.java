package ch12.zy.q4;

public class Account {
     double money=8000;

    public double getMoney() {
        return money;
    }
}
