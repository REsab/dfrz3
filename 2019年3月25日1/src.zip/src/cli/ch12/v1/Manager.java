package cli.ch12.v1;

public class Manager {
    String userName ="admin";
    String password="123";

    public String showName(){

        return userName;
    }
     public String showPwd(){
        password="123";
         return password;
     }


}
