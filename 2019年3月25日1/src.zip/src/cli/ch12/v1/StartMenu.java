package cli.ch12.v1;



public class StartMenu {
    public static void main(String[] args) {

        Menu menu = new Menu();
        menu.run();

    }
}
