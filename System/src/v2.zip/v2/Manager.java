package v2;

public class Manager {
    String userName;
    String password;

    public String showName(){

        return userName;
    }
     public String showPwd(){

         return password;
     }


}
