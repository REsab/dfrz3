package v2;




public class StartMenu {
    public static void main(String[] args) {

        Menu menu = new Menu();
        menu.run();

    }
}
