package ch12.xc.q1;

public class TestCell {
    public static void main(String[] args) {
        Cell feiMaoTui=new Cell();
        feiMaoTui.brand="飞毛腿";
        feiMaoTui.getPower();
    }
}
