package ch12.xc.q1;

public class Cell {
    String brand;

    public void getPower() {

        System.out.println(brand + "正在充电");

    }

}
