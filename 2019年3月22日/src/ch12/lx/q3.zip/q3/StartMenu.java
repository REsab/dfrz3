package ch12.lx.q3;



public class StartMenu {
    public static void main(String[] args) {

        Menu menu = new Menu();
        menu.runSystem();

    }
}
