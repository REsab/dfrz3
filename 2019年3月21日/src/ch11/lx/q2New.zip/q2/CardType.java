package ch11.lx.q2;

public class CardType {
    String cardType;
    public  void  show(){
        System.out.println(this.cardType);
    }
}
