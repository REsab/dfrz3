package ch11.zy.q5;

public class Computer {
     String CPUinfo;
     String motherBoard;
      String  display;
      String disk;
      String menory;

      public  void  showInfo(){

          System.out.println("CPU: " + CPUinfo);
          System.out.println("motherBoard : " + motherBoard);
          System.out.println("display : " + display);
          System.out.println("disk : " + disk);
          System.out.println("menory : " + menory);



      }


}
