package ch11.zy.q3;

public class CurrentTime {
    public String curTime;


     public  void showTime(){
         System.out.println(curTime);
     }


}
