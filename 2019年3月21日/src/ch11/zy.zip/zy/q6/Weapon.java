package ch11.zy.q6;

public class Weapon {
    String name;
    int attckPower;

    public  void showInfo(){

        System.out.println("我是武器,基本信息如下");
        System.out.print("武器名:"+name);
        System.out.println(",攻击力:"+attckPower);


    }
}
