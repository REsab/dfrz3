package ch11.zy.q6;

public class Hero {
    String heroName;
    int liveBlood;

    public void showInfo() {
        System.out.println("我是英雄,我的基本信息如下 :");
        System.out.println("姓名:" + heroName + ",生命值:" + liveBlood);

    }

}
