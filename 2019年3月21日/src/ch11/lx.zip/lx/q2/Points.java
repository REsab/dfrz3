package ch11.lx.q2;

public class Points {
    int points;
    public  void  show(){

        System.out.println(points);

    }


}
