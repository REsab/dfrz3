package ch11.lx.q1;

public class Adimnistrator {
	String name = "admin1";
	int pwd = 111111;

	public void show() {
		System.out.println(name);
		System.out.println(pwd);
	}

}
