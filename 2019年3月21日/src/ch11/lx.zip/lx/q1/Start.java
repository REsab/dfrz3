

import ch11.lx.q1.Adimnistrator;

public class Start {
    public static void main(String[] args) {

        Adimnistrator admin=new Adimnistrator();//实例化 东西
        admin.show();

    }







}
