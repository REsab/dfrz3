package ch11.lx.q5;

import java.util.Set;

public class Customer {

    int points;
    String cardType;

    public void shoPoint() {

        System.out.println(points);

    }

    public void showCard() {
        System.out.println(this.cardType);
    }


}
