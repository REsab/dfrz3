package ch11.lx.q3;

import java.net.SocketTimeoutException;

public class Admin {
   String name;
   int pwd;
   public  void  showName(){
       System.out.println(name);
   }
    public  void  showPwd(){
        System.out.println(pwd);
    }


}
