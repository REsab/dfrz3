package StuSys;

public class test {
     /*

1.       作业1： Stusys_v0b


包名： stusys.ch08.v0b

基于stusysv0，为学生添加性别(String类型)。







2.       作业2： Stusys_v0c

包名： stusys.ch08.v0c


基于stusysv0b，为学生添加年龄(int类型)。
      */


}
